rootProject.name = "PillarPeril"

pluginManagement {
    repositories {
        mavenCentral()
        gradlePluginPortal()
    }
}
